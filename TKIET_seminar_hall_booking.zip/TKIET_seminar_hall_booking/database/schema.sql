-- Drop database if exists
DROP DATABASE IF EXISTS seminar_hall_booking;

-- Create database
CREATE DATABASE seminar_hall_booking;
USE seminar_hall_booking;

-- Drop existing tables if they exist
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS feedbacks;
DROP TABLE IF EXISTS hall_facilities;
DROP TABLE IF EXISTS seminar_halls;
DROP TABLE IF EXISTS admins;
DROP TABLE IF EXISTS users;

-- Create users table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    department VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create admins table
CREATE TABLE admins (
    id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create seminar halls table
CREATE TABLE seminar_halls (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    capacity INT NOT NULL,
    location VARCHAR(255) NOT NULL,
    description TEXT,
    is_available BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Create hall facilities table
CREATE TABLE hall_facilities (
    id INT PRIMARY KEY AUTO_INCREMENT,
    hall_id INT NOT NULL,
    facility_name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hall_id) REFERENCES seminar_halls(id) ON DELETE CASCADE
);

-- Create bookings table
CREATE TABLE IF NOT EXISTS `bookings` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `user_id` INT NOT NULL,
    `hall_id` INT NOT NULL,
    `booking_date` DATE NOT NULL,
    `time_slot_id` INT NOT NULL,
    `purpose` VARCHAR(255) NOT NULL,
    `status` ENUM('PENDING', 'APPROVED', 'REJECTED') DEFAULT 'PENDING',
    `rejection_reason` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`hall_id`) REFERENCES `halls`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`time_slot_id`) REFERENCES `time_slots`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create feedbacks table
CREATE TABLE feedbacks (
    id INT PRIMARY KEY AUTO_INCREMENT,
    booking_id INT NOT NULL,
    user_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert default admin
INSERT INTO admins (full_name, email, password) VALUES 
('Admin User', 'admin@123', 'admin@123');

-- Insert sample seminar halls
INSERT INTO seminar_halls (name, capacity, location, description) VALUES 
('Main Seminar Hall', 200, 'Main Building, Ground Floor', 'Large hall with projector and sound system'),
('Conference Room', 50, 'Admin Block, First Floor', 'Medium-sized room for meetings and presentations'),
('Mini Seminar Hall', 100, 'Academic Block, Second Floor', 'Small hall with basic facilities');

-- Insert sample facilities
INSERT INTO hall_facilities (hall_id, facility_name, description) VALUES 
(1, 'Projector', 'HD Projector with screen'),
(1, 'Sound System', 'Professional audio system with microphones'),
(1, 'Air Conditioning', 'Central AC system'),
(2, 'Smart TV', '55-inch Smart TV for presentations'),
(2, 'Whiteboard', 'Large whiteboard for notes'),
(3, 'Basic Projector', 'Standard definition projector'),
(3, 'Speakers', 'Basic audio system');

-- Seminar halls table
CREATE TABLE IF NOT EXISTS halls (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    capacity INT NOT NULL,
    facilities JSON,
    status ENUM('active', 'maintenance', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    type ENUM('booking_approved', 'booking_rejected', 'booking_cancelled', 'system') NOT NULL,
    message TEXT NOT NULL,
    booking_id INT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    INDEX idx_user_read (user_id, is_read),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Check admin user
SELECT * FROM users WHERE role = 'admin';

-- If no admin exists, insert default admin
INSERT INTO users (full_name, email, password, department, role)
VALUES (
    'Admin User',
    'admin@tkiet.edu',
    '$2a$10$X7UrH5YxX5X5X5X5X5X5X.5X5X5X5X5X5X5X5X5X5X5X5X5X5X5X', -- This is a placeholder, we'll update it
    'Administration',
    'admin'
) ON DUPLICATE KEY UPDATE id = id;

-- Insert sample seminar halls
INSERT INTO halls (name, capacity, facilities, status) VALUES
('Vinay Kore Sanskrutik Bhavan', 500, 
    JSON_ARRAY(
        JSON_OBJECT('name', 'Sound System', 'icon', 'fa-volume-up'),
        JSON_OBJECT('name', 'Projector', 'icon', 'fa-video'),
        JSON_OBJECT('name', 'LED Screen', 'icon', 'fa-tv'),
        JSON_OBJECT('name', 'Guest Room', 'icon', 'fa-door-open'),
        JSON_OBJECT('name', 'Conference Hall', 'icon', 'fa-building')
    ),
    'active'
),
('Chemical Seminar Hall', 200,
    JSON_ARRAY(
        JSON_OBJECT('name', 'Sound System', 'icon', 'fa-volume-up'),
        JSON_OBJECT('name', 'Projector', 'icon', 'fa-video'),
        JSON_OBJECT('name', 'Backstage', 'icon', 'fa-theater-masks')
    ),
    'active'
),
('Civil Seminar Hall', 80,
    JSON_ARRAY(
        JSON_OBJECT('name', 'Sound System', 'icon', 'fa-volume-up'),
        JSON_OBJECT('name', 'Projector', 'icon', 'fa-video')
    ),
    'active'
),
('Mechanical Seminar Hall', 50,
    JSON_ARRAY(
        JSON_OBJECT('name', 'Sound System', 'icon', 'fa-volume-up'),
        JSON_OBJECT('name', 'Projector', 'icon', 'fa-video')
    ),
    'active'
),
('Computer Science Seminar Hall', 50,
    JSON_ARRAY(
        JSON_OBJECT('name', 'Sound System', 'icon', 'fa-volume-up'),
        JSON_OBJECT('name', 'Projector', 'icon', 'fa-video')
    ),
    'active'
);

-- Create time_slots table
CREATE TABLE IF NOT EXISTS `time_slots` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `slot_name` VARCHAR(100) NOT NULL,
    `start_time` TIME NOT NULL,
    `end_time` TIME NOT NULL,
    `is_full_day` BOOLEAN DEFAULT FALSE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert fixed time slots
INSERT INTO `time_slots` (`slot_name`, `start_time`, `end_time`, `is_full_day`) VALUES
('Morning Slot', '10:00:00', '12:00:00', FALSE),
('Afternoon Slot 1', '13:00:00', '15:00:00', FALSE),
('Afternoon Slot 2', '15:00:00', '17:00:00', FALSE),
('Full Day', '10:00:00', '17:00:00', TRUE); 
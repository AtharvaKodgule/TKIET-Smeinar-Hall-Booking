-- Create database if not exists
CREATE DATABASE IF NOT EXISTS seminar_hall_booking;
USE seminar_hall_booking;

-- Drop existing tables if they exist
DROP TABLE IF EXISTS `feedbacks`;
DROP TABLE IF EXISTS `bookings`;
DROP TABLE IF EXISTS `user_roles`;
DROP TABLE IF EXISTS `hall_facilities`;
DROP TABLE IF EXISTS `seminar_halls`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `roles`;

-- Create roles table
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create users table
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(120) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `department` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create user_roles table
CREATE TABLE `user_roles` (
  `user_id` bigint NOT NULL,
  `role_id` int NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_roles_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create seminar_halls table
CREATE TABLE `seminar_halls` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `location` varchar(255) NOT NULL,
  `capacity` int NOT NULL,
  `description` text,
  `has_projector` tinyint(1) DEFAULT '0',
  `has_audio_system` tinyint(1) DEFAULT '0',
  `has_video_conferencing` tinyint(1) DEFAULT '0',
  `has_air_conditioning` tinyint(1) DEFAULT '0',
  `is_available` tinyint(1) DEFAULT '1',
  `department` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create hall_facilities table
CREATE TABLE `hall_facilities` (
  `hall_id` bigint NOT NULL,
  `facility` varchar(100) NOT NULL,
  PRIMARY KEY (`hall_id`,`facility`),
  CONSTRAINT `hall_facilities_ibfk_1` FOREIGN KEY (`hall_id`) REFERENCES `seminar_halls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create bookings table
CREATE TABLE `bookings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `hall_id` bigint NOT NULL,
  `event_title` varchar(255) NOT NULL,
  `event_description` text,
  `booking_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `status` varchar(20) DEFAULT 'PENDING',
  `rejection_reason` text,
  `permission_letter_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `hall_id` (`hall_id`),
  CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`hall_id`) REFERENCES `seminar_halls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Create feedbacks table
CREATE TABLE `feedbacks` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `hall_id` bigint NOT NULL,
  `booking_id` bigint NOT NULL,
  `rating` int NOT NULL,
  `comments` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `hall_id` (`hall_id`),
  KEY `booking_id` (`booking_id`),
  CONSTRAINT `feedbacks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `feedbacks_ibfk_2` FOREIGN KEY (`hall_id`) REFERENCES `seminar_halls` (`id`) ON DELETE CASCADE,
  CONSTRAINT `feedbacks_ibfk_3` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `feedbacks_chk_1` CHECK ((`rating` between 1 and 5))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Insert default roles
INSERT INTO `roles` (`name`) VALUES 
('ROLE_USER'),
('ROLE_FACULTY'),
('ROLE_ADMIN');

-- Insert default admin user (password: admin123)
INSERT INTO `users` (`username`, `first_name`, `last_name`, `email`, `password`, `phone_number`, `department`, `enabled`) 
VALUES ('admin', 'Admin', 'User', 'admin@tkiet.edu', '$2a$10$rDkPvvAFV8c3J7q8q8q8qO8q8q8q8q8q8q8q8q8q8q8q8q8q8q', '1234567890', 'Administration', 1);

-- Assign admin role to admin user
INSERT INTO `user_roles` (`user_id`, `role_id`)
SELECT u.id, r.id
FROM users u, roles r
WHERE u.username = 'admin' AND r.name = 'ROLE_ADMIN';

-- Insert sample seminar halls
INSERT INTO `seminar_halls` (`name`, `location`, `capacity`, `description`, `has_projector`, `has_audio_system`, `has_video_conferencing`, `has_air_conditioning`, `is_available`, `department`) VALUES
('Hall A101', 'Main Building, 1st Floor', 100, 'Large hall with modern facilities', 1, 1, 0, 1, 1, 'Computer Science'),
('Conference Hall', 'Science Block, Ground Floor', 200, 'Large conference hall with full AV setup', 1, 1, 1, 1, 1, 'General'),
('Seminar Hall B', 'Library Building, 2nd Floor', 150, 'Medium-sized hall with basic facilities', 1, 1, 0, 1, 1, 'Electrical Engineering');

-- Insert sample facilities for halls
INSERT INTO `hall_facilities` (`hall_id`, `facility`) VALUES
(1, 'Projector'),
(1, 'Audio System'),
(1, 'Air Conditioning'),
(2, 'Projector'),
(2, 'Audio System'),
(2, 'Video Conferencing'),
(2, 'Air Conditioning'),
(3, 'Projector'),
(3, 'Audio System'),
(3, 'Air Conditioning'); 
-- Disable foreign key checks temporarily
SET FOREIGN_KEY_CHECKS = 0;

-- Create halls table if it doesn't exist
CREATE TABLE IF NOT EXISTS `halls` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `hall_name` varchar(100) NOT NULL,
  `capacity` int NOT NULL,
  `facilities` JSON,
  `status` ENUM('active', 'maintenance', 'inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `hall_name` (`hall_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Migrate data from seminar_halls to halls
INSERT INTO halls (id, hall_name, capacity, facilities, status)
SELECT 
    id,
    name as hall_name,
    capacity,
    JSON_ARRAY(
        JSON_OBJECT(
            'name', 'Projector',
            'icon', 'fa-video'
        ),
        JSON_OBJECT(
            'name', 'Audio System',
            'icon', 'fa-volume-up'
        ),
        JSON_OBJECT(
            'name', 'Video Conferencing',
            'icon', 'fa-video'
        ),
        JSON_OBJECT(
            'name', 'Air Conditioning',
            'icon', 'fa-snowflake'
        )
    ) as facilities,
    CASE 
        WHEN is_available = 1 THEN 'active'
        ELSE 'inactive'
    END as status
FROM seminar_halls;

-- Update foreign key references in bookings table
ALTER TABLE bookings
DROP FOREIGN KEY bookings_ibfk_2,
ADD CONSTRAINT bookings_ibfk_2 
FOREIGN KEY (hall_id) REFERENCES halls(id) ON DELETE CASCADE;

-- Update foreign key references in feedbacks table
ALTER TABLE feedbacks
DROP FOREIGN KEY feedbacks_ibfk_2,
ADD CONSTRAINT feedbacks_ibfk_2 
FOREIGN KEY (hall_id) REFERENCES halls(id) ON DELETE CASCADE;

-- Drop old tables
DROP TABLE IF EXISTS hall_facilities;
DROP TABLE IF EXISTS seminar_halls;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1; 